# NetApp trident for openshift

Trident integrates natively with Kubernetes and its Persistent Volume framework to seamlessly provision and manage volumes from systems running NetApp’s ONTAP. It allows users to request and manage persistent volumes using native Kubernetes interfaces and constructs. It’s designed to work in a way that users can take advantage of the underlying capabilities of your storage infrastructure without having to know anything about it.

# Getting Started

**Prerequisites**

The following packages need to be installed
* ansible 2.9.6
* python3
* pip
* lxml, oslo_log, netapp-lib(python packages installed with PIP)
* git


# Getting a copy of the playbook

These instructions will get you a copy of the playbooks.

```
git clone http://gitlab.verizon.com/vcp/webscale/automation/environments/trident

cd trident
```


**There are two playbooks available:**

pb.trident-vserver-setup.yml  - 

* Creates the vserver on the netapp ontap system 
* Creates the backend config files needed by trident and storage class files needed by kubernetes 
* installs trident as an operator on the Kubernetes cluster
* run post deployment checks to ensure PVCs can be attached to pods and check RWX access


pb.trident-vserver-uninstall.yml -

* uninstalls trident on the Kubernetes cluster 
* deletes the vserver associated with the Kubernetes cluster on the ontap system


# Tasks associated with the playbooks

**Tasks associated with playbook pb.trident-vserver-setup.yml**

*Tasks done on ontap systems:*

* Create Vserver
* create LS Volumes
* Create LS snapmirror relationships
* Initialize LS SnapMirror
* limit FlexVol count creation
* create MGMT VLAN for node1
* create MGMT VLAN for node2
* create DATA VLAN for node1
* create DATA VLAN for node2
* create MGMT broadcast domain
* create data broadcast domain
* nfs setup
* create MGMT interface
* create Data interface
* Create export policy rules
* Create Trident User
* Create mgmt route
* Create data route
* Output facts to file - clustername_facts.json in current directory


*Tasks done on ansible server:*

* Install jq on ansible server
* create directory on ansible server to store config files
* create nas economy backend config file for node 1
* create nas economy backend config file for node 2
* create sc config file for standard
* create nas backend config file for node 1
* create nas  backend config file for node 2
* create sc config file for premium


*Tasks done on Kubernetes cluster:*

* copy config files from ansible server to Kubernetes cluster
* Download trident tar ball
* Extract the trident tar ball
* check if trident is installed
* check privileges to install trident
* create trident namespace
* create TridentProvisioner
* get TridentProvisioner crs
* Update operator image in yml files
* Generate bundle.yaml using kustomize
* deploy trident operator
* Wait for trident-operator pod to be created
* wait for trident operator pod to be ready
* Sleep for 60 seconds
* copy TridentProvisioner CR yaml file
* install trident
* Wait for trident to be installed
* check trident installation
* fail if trident is not installed
* Create trident backends for standard
* Create k8s storage class for standard
* Create trident backends for premium
* Create k8s storage class for premium
* remove config directory for security reasons
* Copy post test yml files
* Update registry info in  yml files
* Create PVC
* Sleep for 30 seconds
* Get the PVC status
* Check PVC existence
* Create pods
* Wait for test pods to be created
* wait for test pods to be ready
* Get mountpoint on pod1
* Get mountpoint on pod2
* Check same PV mounted on both pods
* create a file on pod1
* test file access from pod2
* Check RWX access
* Cleanup the pod
* Cleanup the PVC
* remove test yml files


**Tasks associated with playbook pb.trident-vserver-uninstall.yml**

*Tasks done on Kubernetes cluster:*

* check if trident is installed
* Uninstall trident
* Wait for trident to be uninstalled
* delete trident resources
* Sleep for 10 seconds
* delete trident provisioner crd
* Sleep for 10 seconds
* Delete trident namespace


*Tasks done on ontap system:*

* get list of flexvolumes to be deleted
* Delete Trident User
* Delete mgmt route
* Delete MGMT interface
* Delete Data interface
* Delete SnapMirror
* delete Volumes
* Delete Vserver
* delete MGMT VLAN on node1
* delete MGMT VLAN for node2
* delete DATA VLAN for node1
* delete DATA VLAN for node2
* delete MGMT broadcast domain
* delete data broadcast domain


# Variables used by the playbooks

*Variables need to be modified based on the environment*


> Please note you need a separate vserver for each kubernetes cluster


**Explanation of variables used**

```
netapp_cluster_ip: netapp cluster mgmt ip address
netapp_username: username to access the netapp cluster. User with admin privileges
netapp_password: password to access the netapp cluster
#**pod_id should be a numerical value**
pod_id: the pod where Kubernetes cluster is deployed
k8s_cluster_name: Kubernetes cluster name
kubeconfig: path to kubeconfig file
registry: registry to download trident images and busybox images
http_proxy: http/https proxy server
trident_url: url to install trident
TRIDENT_PASSWORD: password to be used by trident to communicate with netapp
trident_operator_image_location: path to trident images in the registry
busy_box_image_location: path to busybox images
#*only two options for storage class flavors - standard and premium. you can choose either or both*
sc_flavor: premium storageclass using netapp flexvol as PVC and standard storageclass uses netapp qtree as PVC. Standard flavor is the default storage class
#*the svm_id value should be a numerical value. it should denote the nth vserver being created.*
vserver:
  - svm_id: id to denote the nth svm created for the Kubernetes cluster
    mgmt_node1_ifgrp: mgmt ifgrp to be used on the netapp cluster for node1
    mgmt_node2_ifgrp: mgmt ifgrp to be used on the netapp cluster for node2
    mgmt_vlan: mgmt vlan to be used on netapp cluster
    data_node1_ifgrp: data ifgrp to be used on the netapp cluster for node1
    data_node2_ifgrp: dat ifgrp to be used on the netapp cluster for node2
    data_vlan: data vlan to be used on netapp cluste
    mgmt_ip: mgmt. ip for the netapp cluster that will be used by trident
    data_ip: data ips for the netapp cluster that will be used by Kubernetes to access PVs
    mgmt_access_subnet: the kubernetes subnet that needs access to the netapp mgmt. ip
    data_access_subnet: the Kubernetes subnet that needs access to netapp data ips
    mgmt_gateway: the gateway for netapp mgmt. network
    data_gateway: the gateway for netapp data network
#*maximum flex volumes that can be created for the vserver*
    flexvol_limit: limit on the number of flex volumes that can be created on the vserver
#*trident user should be 15 characters or less*
    trident_user: the username trident will use to access the netapp
```

**Example:**

```
netapp_cluster_ip: '10.75.52.45'
netapp_username: 'os_admin'
netapp_password: 'test1'
# pod_id should be a numerical value
pod_id: '5'
k8s_cluster_name: 'betadev2'
kubeconfig: "/home/corona/betadev2/auth/kubeconfig"
registry: "wsregistry.vici.verizon.com:5000"
http_proxy: "http://96.239.250.29:80"
trident_url: "http://10.75.15.16/trident/trident-installer-20.04.0.tar.gz"
TRIDENT_PASSWORD: 'Verizon1'
trident_operator_image_location: "wsregistry.vici.verizon.com:5000/netapp/trident-operator:20.04.0"
busy_box_image_location: "wsregistry.vici.verizon.com:5000/corona/busybox"
#only two options for storage class flavors - standard and premium. you can choose either or both
sc_flavor: ['standard','premium']
#the svm_id value should be  a numerical value. it should denote the nth vserver being created.
vserver:
  - svm_id: '1'
    mgmt_node1_ifgrp: 'a1a'
    mgmt_node2_ifgrp: 'a2a'
    mgmt_vlan: '963'
    data_node1_ifgrp: 'a1a'
    data_node2_ifgrp: 'a2a'
    data_vlan: '63'
    mgmt_ip: '172.18.251.13/29'
    data_ip: ['172.18.250.14/29','172.18.250.13/29']
    mgmt_access_subnet: '10.75.71.32/27'
    data_access_subnet: '0.0.0.0/0'
    mgmt_gateway: '172.18.251.9'
    data_gateway: '172.18.250.9'
# maximum flex volumes that can be created for the vserver
    flexvol_limit: '75'
# trident user should be 15 characters or less
    trident_user: 'admin_betadev2'
```

# Running the playbook
**To create vserver on the ontap system and install trident as an operator in Kubernetes cluster**

`ansible-playbook pb.trident-vserver-setup.yml -vvv`

**To uninstall trident from the Kubernetes cluster and delete vserver associated with the kubenetes cluster**

`ansible-playbook pb.trident-vserver-uninstall.yml -vvv`



# Post Installation Checks

To run the post installation checks for trident, please follow the instrunctions at:  https://gitlab.verizon.com/vcp/webscale/automation/tests-post-deployment/-/blob/develop/README.md



# Authors

* Promoth Pushpanathan
* Bharath Thiruveedula 


