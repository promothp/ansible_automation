# NetApp trident for openshift

Trident integrates natively with Kubernetes and its Persistent Volume framework to seamlessly provision and manage volumes from systems running NetApp’s ONTAP. It allows users to request and manage persistent volumes using native Kubernetes interfaces and constructs. It’s designed to work in a way that users can take advantage of the underlying capabilities of your storage infrastructure without having to know anything about it.

# Getting Started

**Prerequisites**

The following packages need to be installed
* ansible 2.8
* python3
* pip
* lxml, oslo_log, netapp-lib(python packages installed with PIP)
* git


# Getting a copy of the playbook

These instructions will get you a copy of the playbooks.

```
git clone http://wsgitlab.vici.verizon.com/environments/netapp_csi.git netapp_csi

cd netapp_csi/
```


**There are two playbooks available:**

pb.trident-vserver-setup.yml  - 

* Creates the vserver on the netapp ontap system 
* Creates the backend config files needed by trident and storage class files needed by kubernetes 
* installs trident as an operator on the Kubernetes cluster
* run post deployment checks to ensure PVCs can be attached to pods and check RWX access


pb.trident-vserver-uninstall.yml – 

* uninstalls trident on the Kubernetes cluster 
* deletes the vserver associated with the Kubernetes cluster on the ontap system


# Tasks associated with the playbooks

**Tasks associated with playbook pb.trident-vserver-setup.yml**

*Tasks done on ontap systems:*

* Remove ports from the default broadcast domain
* Modify network port settings
* create ifgrp
* modify mtu size for the ifgrp
* create MGMT VLAN
* create DATA VLAN
* create MGMT broadcast domain
* create DATA broadcast domain
* Create Vserver
* set permissions for the root volume
* create export policy rules for the root volume
* create LS Volumes
* Create LS snapmirror relationships
* Initialize LS SnapMirror
* limit FlexVol count creation
* nfs setup
* create MGMT interface
* create Data interface
* Create mgmt route
* Create data route
* configure nfsv3
* Create Trident User
* Output facts to file - clustername_facts.json in tmp directory
* Keep latest 3 copies of clustername_facts.json


*Tasks done on ansible server:*

* Install jq on ansible server
* create directory on ansible server to store config files
* create nas economy backend config file for node 1
* create nas economy backend config file for node 2
* create sc config file for standard
* create nas backend config file for node 1
* create nas  backend config file for node 2
* create sc config file for premium


*Tasks done on Kubernetes cluster:*

* copy config files from ansible server to Kubernetes cluster
* Download trident tar ball
* Extract the trident tar ball
* check if trident is installed
* check privileges to install trident
* create trident namespace
* create TridentProvisioner
* get TridentProvisioner crs
* Update operator image in yml files
* Generate bundle.yaml using kustomize
* deploy trident operator
* Wait for trident-operator pod to be created
* wait for trident operator pod to be ready
* Sleep for 60 seconds
* copy TridentProvisioner CR yaml file
* install trident
* Wait for trident to be installed
* check trident installation
* fail if trident is not installed
* Create trident backends for standard
* Create k8s storage class for standard
* Create trident backends for premium
* Create k8s storage class for premium
* remove config directory for security reasons
* Copy post test yml files
* Update registry info in  yml files
* Create PVC
* Sleep for 30 seconds
* Get the PVC status
* Check PVC existence
* Create pods
* Wait for test pods to be created
* wait for test pods to be ready
* Get mountpoint on pod1
* Get mountpoint on pod2
* Check same PV mounted on both pods
* create a file on pod1
* test file access from pod2
* Check RWX access
* Cleanup the pod
* Cleanup the PVC
* remove test yml files


**Tasks associated with playbook pb.trident-vserver-uninstall.yml**

*Tasks done on Kubernetes cluster:*

* check if trident is installed
* Uninstall trident
* Wait for trident to be uninstalled
* delete trident resources
* Sleep for 10 seconds
* delete trident provisioner crd
* Sleep for 10 seconds
* Delete trident namespace


*Tasks done on ontap system:*

* get list of flexvolumes to be deleted
* Delete Trident User
* Delete mgmt route
* Delete MGMT interface
* Delete Data interface
* Delete SnapMirror
* delete Volumes
* Delete Vserver
* delete MGMT VLAN on node1
* delete MGMT VLAN for node2
* delete DATA VLAN for node1
* delete DATA VLAN for node2
* delete MGMT broadcast domain
* delete data broadcast domain


# Variables used by the playbooks

*Variables need to be modified based on the environment*


> Please note you need a separate vserver for each kubernetes cluster


**Explanation of variables used**

```
netapp_hostname: netapp cluster mgmt ip address
netapp_username: username to access the netapp cluster. User with admin privileges
netapp_password: password to access the netapp cluster
#**pod_id should be a numerical value**
pod_id: the pod where Kubernetes cluster is deployed
k8s_cluster_name: Kubernetes cluster name
kubeconfig: path to kubeconfig file
registry: registry to download trident images and busybox images
trident_url: url to install trident
TRIDENT_PASSWORD: password to be used by trident to communicate with netapp
trident_operator_image_location: path to trident images in the registry
busy_box_image_location: path to busybox images
#*only two options for storage class flavors - standard and premium. you can choose either or both*
sc_flavor: premium storageclass using netapp flexvol as PVC and standard storageclass uses netapp qtree as PVC. Standard flavor is the default storage class
vserver:
  - site_code: site code where kubernetes cluster is being deployed
    storage_mgmt_vlan: mgmt vlan to be used on netapp cluster
    storage_vlan: data vlan to be used on netapp cluste
    storage_mgmt: mgmt. ip for the netapp cluster that will be used by trident
    storage: data ips for the netapp cluster that will be used by Kubernetes to access PVs
    storage_mgmt_access_subnet: the kubernetes subnet that needs access to the netapp mgmt. ip
    storage_access_subnet: the Kubernetes subnet that needs access to netapp data ips
    storage_mgmt_gateway: the gateway for netapp mgmt. network
    storage_gateway: the gateway for netapp data network
#*maximum flex volumes that can be created for the vserver*
    flexvol_limit: limit on the number of flex volumes that can be created on the vserver
#*trident user should be 15 characters or less*
    trident_user: the username trident will use to access the netapp
    fabric: fabric on which the vserver needs to be created
laggs:
  - fabric: fabric on the netapp that needs to be created
    ports:
      - list of ports on the netapp that needs to be part of the fabric and same ifgrp

```

**Example:(core.yml)**

```

netapp_hostname: '10.75.58.44'
netapp_username: 'os_admin'
netapp_password: 'Verizon1'
# pod_id should be a numerical value
pod_id: '5'
#vcp infra refers to the infrastructure on which webscale is deployed.choose either webscale-edge or webscale-core
vcp_infra: 'webscale-core'
k8s_cluster_name: 'betadev22'
kubeconfig: "/home/corona/betadev2/auth/kubeconfig"
registry: "wsregistry.vici.verizon.com:5000"
http_proxy: "http://96.239.250.29:80"
trident_url: "http://10.75.15.16/trident/trident-installer-20.04.0.tar.gz"
trident_operator_image_location: "wsregistry.vici.verizon.com:5000/netapp/trident-operator:20.04.0"
busy_box_image_location: "wsregistry.vici.verizon.com:5000/corona/busybox"
#only two options for storage class flavors - standard and premium. you can choose either or both
sc_flavor: ['standard','premium']
TRIDENT_PASSWORD: 'Verizon1'
#the svm_id value should be  a numerical value. it should denote the nth vserver being created.
vserver:
  - site_code: 'tpa'
    storage_mgmt_vlan: '913'
    storage_vlan: '13'
    storage_mgmt: '172.33.251.13/29'
    storage: ['172.33.250.13/29','172.33.250.14/29']
    storage_mgmt_access_subnet: '10.33.71.32/27'
    storage_access_subnet: '0.0.0.0/0'
    storage_mgmt_gateway: '172.33.251.9'
    storage_gateway: '172.33.250.9'
# maximum flex volumes that can be created for the vserver
    flexvol_limit: '100'
# trident user should be 15 characters or less
    trident_user: 'adm_betadev22'
    fabric: a

laggs:
  - fabric: a
    ports:
      - e2a
      - e2b

```

# Running the playbook
**To configure the ontap system and install trident as an operator in Kubernetes cluster**

`ansible-playbook pb.trident-vserver-setup.yml --extra-vars "@core.yml"`

**To uninstall trident from the Kubernetes cluster and delete vserver associated with the kubenetes cluster**

`ansible-playbook pb.trident-vserver-uninstall.yml --extra-vars "@core.yml"`

**To only install trident as an operator on the kubernetes cluster**

`ansible-playbook pb.trident-vserver-setup.yml --tags trident-k8s-setup --extra-vars "@core.yml"`

**To configure the ontap system and not install trident**

`ansible-playbook pb.trident-vserver-setup.yml --tags trident-vserver-setup --extra-vars "@core.yml"`

**To only configure network on the ontap system**

`ansible-playbook pb.trident-vserver-setup.yml --tags run_network_core --extra-vars "@core.yml"`

**To only configure vserver on the ontap system**

`ansible-playbook pb.trident-vserver-setup.yml --tags run_vserver_core --extra-vars "@core.yml"`

**To only configure nfs on the ontap system**

`ansible-playbook pb.trident-vserver-setup.yml --tags run_nfs_core --extra-vars "@core.yml"`

**To only configure user for trident on the ontap system**

`ansible-playbook pb.trident-vserver-setup.yml --tags run_user_core --extra-vars "@core.yml"`

**To only collect facts of the ontap system**

`ansible-playbook pb.trident-vserver-setup.yml --tags run_facts_core --extra-vars "@core.yml"`



# Authors

* Bharath Thiruveedula
* Promoth Pushpanathan
* Sridhar Chirravuri
* Stephen Reilly
* Vicky khatwani


